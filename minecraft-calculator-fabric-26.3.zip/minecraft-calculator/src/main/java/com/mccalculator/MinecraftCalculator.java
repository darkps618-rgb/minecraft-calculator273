package com.mccalculator;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

public class MinecraftCalculator implements ModInitializer {
	public static final String MOD_ID = "mccalculator";

	@Override
	public void onInitialize() {
		CommandRegistrationCallback.EVENT.register(CalcCommands::register);
	}
}
