package com.mccalculator;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.math.BigDecimal;
import java.math.RoundingMode;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * /calc add|sub|mul|div <a> <b>
 * /calc item <op> <item> <amount>                 (your inventory)
 * /calc chest <pos> <op> <item> <amount>          (modify a chest)
 * /calc chest <pos> count <item>
 * /calc chests <pos1> <pos2> <op> <item>          (calculate with two chests' counts, no changes)
 * Long names work too: plus, minus, multiply, divide.
 */
public final class CalcCommands {
	private static final SimpleCommandExceptionType DIV_ZERO =
			new SimpleCommandExceptionType(Component.literal("Cannot divide by zero."));
	private static final SimpleCommandExceptionType NOT_CONTAINER =
			new SimpleCommandExceptionType(Component.literal("There is no chest/container at that position."));

	private CalcCommands() {}

	public static void register(CommandDispatcher<CommandSourceStack> dispatcher, CommandBuildContext buildContext,
			Commands.CommandSelection environment) {
		LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("calc");

		// ---- plain numbers ----
		for (Op op : Op.values()) {
			for (String name : op.names) {
				root.then(Commands.literal(name)
						.then(Commands.argument("a", DoubleArgumentType.doubleArg())
								.then(Commands.argument("b", DoubleArgumentType.doubleArg())
										.executes(c -> numbers(c, op)))));
			}
		}

		// ---- player inventory ----
		LiteralArgumentBuilder<CommandSourceStack> item = Commands.literal("item");
		for (Op op : Op.values()) {
			for (String name : op.names) {
				item.then(Commands.literal(name)
						.then(Commands.argument("item", ItemArgument.item(buildContext))
								.then(Commands.argument("amount", IntegerArgumentType.integer(0))
										.executes(c -> {
											Inv inv = new Inv(c.getSource().getPlayerOrException().getInventory(), 36);
											return apply(c, op, inv, "Inventory");
										}))));
			}
		}
		item.then(Commands.literal("count")
				.then(Commands.argument("item", ItemArgument.item(buildContext))
						.executes(c -> {
							Inv inv = new Inv(c.getSource().getPlayerOrException().getInventory(), 36);
							Item it = itemOf(c);
							int n = inv.count(it);
							say(c, Component.literal("Inventory has " + n + " ").append(name(it)));
							return n;
						})));
		root.then(item);

		// ---- one chest ----
		LiteralArgumentBuilder<CommandSourceStack> chest = Commands.literal("chest");
		RequiredArgumentBuilder<CommandSourceStack, ?> pos = Commands.argument("pos", BlockPosArgument.blockPos());
		for (Op op : Op.values()) {
			for (String name : op.names) {
				pos.then(Commands.literal(name)
						.then(Commands.argument("item", ItemArgument.item(buildContext))
								.then(Commands.argument("amount", IntegerArgumentType.integer(0))
										.executes(c -> {
											Inv inv = new Inv(containerAt(c, "pos"), Integer.MAX_VALUE);
											return apply(c, op, inv, "Chest");
										}))));
			}
		}
		pos.then(Commands.literal("count")
				.then(Commands.argument("item", ItemArgument.item(buildContext))
						.executes(c -> {
							Item it = itemOf(c);
							int n = new Inv(containerAt(c, "pos"), Integer.MAX_VALUE).count(it);
							say(c, Component.literal("Chest has " + n + " ").append(name(it)));
							return n;
						})));
		chest.then(pos);
		root.then(chest);

		// ---- two chests: calculate with their counts ----
		LiteralArgumentBuilder<CommandSourceStack> chests = Commands.literal("chests");
		RequiredArgumentBuilder<CommandSourceStack, ?> pos2 = Commands.argument("pos2", BlockPosArgument.blockPos());
		for (Op op : Op.values()) {
			for (String name : op.names) {
				pos2.then(Commands.literal(name)
						.then(Commands.argument("item", ItemArgument.item(buildContext))
								.executes(c -> {
									Item it = itemOf(c);
									int a = new Inv(containerAt(c, "pos1"), Integer.MAX_VALUE).count(it);
									int b = new Inv(containerAt(c, "pos2"), Integer.MAX_VALUE).count(it);
									if (op == Op.DIV && b == 0) throw DIV_ZERO.create();
									double r = op.apply(a, b);
									say(c, Component.literal("Chest A has " + a + ", Chest B has " + b + " ")
											.append(name(it)).append(Component.literal(":  " + a + " " + op.symbol
													+ " " + b + " = " + fmt(r))));
									return clamp(r);
								})));
			}
		}
		chests.then(Commands.argument("pos1", BlockPosArgument.blockPos()).then(pos2));
		root.then(chests);

		// ---- help ----
		root.executes(c -> {
			say(c, Component.literal("Minecraft Calculator\n"
					+ "/calc add|sub|mul|div <a> <b>\n"
					+ "/calc item <op> <item> <amount>\n"
					+ "/calc chest <pos> <op> <item> <amount>\n"
					+ "/calc chest <pos> count <item>\n"
					+ "/calc chests <pos1> <pos2> <op> <item>"));
			return 1;
		});

		dispatcher.register(root);
	}

	// ------------------------------------------------------------------

	private static int numbers(CommandContext<CommandSourceStack> c, Op op) throws CommandSyntaxException {
		double a = DoubleArgumentType.getDouble(c, "a");
		double b = DoubleArgumentType.getDouble(c, "b");
		if (op == Op.DIV && b == 0) throw DIV_ZERO.create();
		double r = op.apply(a, b);
		say(c, Component.literal(fmt(a) + " " + op.symbol + " " + fmt(b) + " = " + fmt(r)));
		return clamp(r);
	}

	/**
	 * ADD: put <amount> items in.  SUB: take <amount> out.
	 * MUL: multiply the current count by <amount>.  DIV: divide the current count by <amount> (rounded down).
	 */
	private static int apply(CommandContext<CommandSourceStack> c, Op op, Inv inv, String where)
			throws CommandSyntaxException {
		Item it = itemOf(c);
		int amount = IntegerArgumentType.getInteger(c, "amount");
		int before = inv.count(it);
		String note = "";

		switch (op) {
			case ADD -> {
				int placed = inv.add(it, amount);
				if (placed < amount) note = "  (only " + placed + " fit)";
			}
			case SUB -> inv.remove(it, amount);
			case MUL -> {
				if (amount == 0) {
					inv.remove(it, before);
				} else {
					long extra = (long) before * (amount - 1L);
					int want = (int) Math.min(extra, Integer.MAX_VALUE);
					int placed = inv.add(it, want);
					if (placed < want) note = "  (not enough room)";
				}
			}
			case DIV -> {
				if (amount == 0) throw DIV_ZERO.create();
				inv.remove(it, before - before / amount);
			}
		}

		int after = inv.count(it);
		say(c, Component.literal(where + ": ").append(name(it))
				.append(Component.literal("  " + before + " " + op.symbol + " " + amount + " -> " + after + note)));
		return after;
	}

	private static Item itemOf(CommandContext<CommandSourceStack> c) {
		return ItemArgument.getItem(c, "item").getItem().value();
	}

	private static Component name(Item it) {
		return Component.translatable(it.getDescriptionId());
	}

	private static Container containerAt(CommandContext<CommandSourceStack> c, String arg)
			throws CommandSyntaxException {
		ServerLevel level = c.getSource().getLevel();
		BlockPos p = BlockPosArgument.getLoadedBlockPos(c, arg);
		BlockState st = level.getBlockState(p);
		Container found = null;
		if (st.getBlock() instanceof ChestBlock cb) {
			found = ChestBlock.getContainer(cb, st, level, p, true); // merges double chests
		}
		if (found == null && level.getBlockEntity(p) instanceof Container be) {
			found = be; // barrels, hoppers, shulker boxes...
		}
		if (found == null) throw NOT_CONTAINER.create();
		return found;
	}

	private static void say(CommandContext<CommandSourceStack> c, Component msg) {
		c.getSource().sendSuccess(() -> msg, false);
	}

	private static int clamp(double v) {
		return (int) Math.max(Integer.MIN_VALUE, Math.min(Integer.MAX_VALUE, Math.round(v)));
	}

	private static String fmt(double v) {
		if (Double.isNaN(v) || Double.isInfinite(v)) return Double.toString(v);
		return new BigDecimal(v).setScale(6, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
	}
}
