package com.mccalculator;

/** The four operations. Each has a short and a long command name. */
public enum Op {
	ADD("+", "add", "plus"),
	SUB("-", "sub", "minus"),
	MUL("*", "mul", "multiply"),
	DIV("/", "div", "divide");

	public final String symbol;
	public final String[] names;

	Op(String symbol, String... names) {
		this.symbol = symbol;
		this.names = names;
	}

	public double apply(double a, double b) {
		return switch (this) {
			case ADD -> a + b;
			case SUB -> a - b;
			case MUL -> a * b;
			case DIV -> a / b;
		};
	}
}
