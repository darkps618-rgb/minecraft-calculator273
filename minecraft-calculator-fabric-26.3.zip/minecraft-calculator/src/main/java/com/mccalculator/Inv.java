package com.mccalculator;

import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Small helper that counts / adds / removes one item type in any Container (chest, barrel, player inventory...). */
public final class Inv {
	private final Container c;
	private final int slots;

	public Inv(Container c, int maxSlots) {
		this.c = c;
		this.slots = Math.min(c.getContainerSize(), maxSlots);
	}

	public int count(Item item) {
		long total = 0;
		for (int i = 0; i < slots; i++) {
			ItemStack s = c.getItem(i);
			if (!s.isEmpty() && s.is(item)) total += s.getCount();
		}
		return (int) Math.min(total, Integer.MAX_VALUE);
	}

	/** Returns how many items actually fit. */
	public int add(Item item, int amount) {
		int left = amount;
		for (int i = 0; i < slots && left > 0; i++) {
			ItemStack s = c.getItem(i);
			if (!s.isEmpty() && s.is(item) && s.getCount() < s.getMaxStackSize()) {
				int move = Math.min(left, s.getMaxStackSize() - s.getCount());
				s.grow(move);
				left -= move;
			}
		}
		int max = new ItemStack(item).getMaxStackSize();
		for (int i = 0; i < slots && left > 0; i++) {
			if (c.getItem(i).isEmpty()) {
				int n = Math.min(left, max);
				c.setItem(i, new ItemStack(item, n));
				left -= n;
			}
		}
		c.setChanged();
		return amount - left;
	}

	/** Returns how many items were actually removed. */
	public int remove(Item item, int amount) {
		int left = amount;
		for (int i = slots - 1; i >= 0 && left > 0; i--) {
			ItemStack s = c.getItem(i);
			if (!s.isEmpty() && s.is(item)) {
				int take = Math.min(left, s.getCount());
				s.shrink(take);
				if (s.isEmpty()) c.setItem(i, ItemStack.EMPTY);
				left -= take;
			}
		}
		c.setChanged();
		return amount - left;
	}
}
