# Minecraft Calculator (Fabric, Minecraft 26.3)

Needs: JDK 25, Gradle 9.3+, Fabric Loader 0.19.5+, Fabric API 0.160.5+26.3.

## Build
    gradle wrapper --gradle-version 9.3   # once, if there is no gradlew yet
    ./gradlew build
The mod jar is in build/libs/ (use the one WITHOUT -sources). Put it + Fabric API in your mods folder.
(Or open the folder in IntelliJ IDEA and run the "build" Gradle task.)

## Commands (long names plus/minus/multiply/divide also work)
Numbers:
    /calc add 5 3          -> 5 + 3 = 8
    /calc sub 10 4.5
    /calc mul 6 7
    /calc div 22 7

Items in your inventory:
    /calc item add minecraft:diamond 5     give 5
    /calc item sub minecraft:diamond 2     remove 2
    /calc item mul minecraft:iron_ingot 3  triple what you carry
    /calc item div minecraft:iron_ingot 2  halve it (rounded down)
    /calc item count minecraft:diamond

Chests (also barrels, shulkers, double chests):
    /calc chest 10 64 10 add minecraft:cobblestone 128
    /calc chest 10 64 10 sub minecraft:cobblestone 64
    /calc chest 10 64 10 mul minecraft:cobblestone 2
    /calc chest 10 64 10 div minecraft:cobblestone 4
    /calc chest 10 64 10 count minecraft:cobblestone

Calculate with two chests (read-only):
    /calc chests 10 64 10 12 64 10 add minecraft:diamond   (A + B)
    /calc chests 10 64 10 12 64 10 div minecraft:diamond   (A / B)

Note: commands are open to all players. To restrict to operators, add
.requires(...) with your version's permission check to `root`.
